<?php

$ToEmail = $_REQUEST['toEmail'];
$ToName = $_REQUEST['toName'];
$ToSubject = $_REQUEST['subject'];

$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$phone = $_REQUEST['phone'];
$comment = $_REQUEST['comments'];

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From:'.$name. "\r\n" .'Reply-To: '.$email . "\r\n";

$EmailBody = "Name: ".$name."<br/><br/>Phone: ".$email."<br/><br/>Email: ".$phone."<br/><br/>Comments: ".$comment."<br/><br/>";

$Message = $EmailBody;

mail($ToName." <".$ToEmail.">",$ToSubject, $Message, $headers);


?>



